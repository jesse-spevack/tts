"use strict";
(() => {
  // src/auth.ts
  var TOKEN_KEY = "tts_api_token";
  async function getToken() {
    return new Promise((resolve, reject) => {
      chrome.storage.sync.get([TOKEN_KEY], (result) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(result[TOKEN_KEY] || null);
        }
      });
    });
  }
  async function clearToken() {
    return new Promise((resolve, reject) => {
      chrome.storage.sync.remove([TOKEN_KEY], () => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve();
        }
      });
    });
  }
  async function isConnected() {
    const token = await getToken();
    return token !== null;
  }

  // src/icons.ts
  var ICON_CONFIGS = {
    neutral: {
      badgeText: "",
      badgeColor: "#8c8fa1"
      // Catppuccin overlay1
    },
    loading: {
      badgeText: "...",
      badgeColor: "#1e66f5"
      // Catppuccin blue
    },
    success: {
      badgeText: "\u2713",
      badgeColor: "#40a02b"
      // Catppuccin green
    },
    error: {
      badgeText: "!",
      badgeColor: "#d20f39"
      // Catppuccin red
    },
    offline: {
      badgeText: "\u25CB",
      badgeColor: "#8c8fa1"
      // Catppuccin overlay1
    },
    rate_limited: {
      badgeText: "\u23F3",
      badgeColor: "#df8e1d"
      // Catppuccin yellow
    }
  };
  var AUTO_REVERT_DELAY = 2500;
  var revertTimeout = null;
  async function setIconState(state) {
    if (revertTimeout) {
      clearTimeout(revertTimeout);
      revertTimeout = null;
    }
    const config = ICON_CONFIGS[state];
    await Promise.all([
      setBadgeText(config.badgeText),
      setBadgeBackgroundColor(config.badgeColor)
    ]);
    if (state === "success" || state === "error" || state === "rate_limited") {
      revertTimeout = setTimeout(() => {
        setIconState("neutral");
      }, AUTO_REVERT_DELAY);
    }
  }
  function setBadgeText(text) {
    return new Promise((resolve) => {
      chrome.action.setBadgeText({ text }, resolve);
    });
  }
  function setBadgeBackgroundColor(color) {
    return new Promise((resolve) => {
      chrome.action.setBadgeBackgroundColor({ color }, resolve);
    });
  }

  // src/api.ts
  var API_BASE_URL = "https://www.verynormal.fyi";
  async function createEpisode(token, request) {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/episodes`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(request)
      });
      if (response.ok) {
        const data = await response.json();
        return { success: true, data };
      }
      const errorData = await response.json();
      const result = {
        success: false,
        status: response.status,
        error: errorData.error || getDefaultErrorMessage(response.status)
      };
      if (response.status === 429) {
        const retryAfter = response.headers.get("Retry-After");
        if (retryAfter) {
          result.retryAfter = parseInt(retryAfter, 10);
        }
      }
      return result;
    } catch (error) {
      return {
        success: false,
        status: 0,
        error: error instanceof Error ? error.message : "Network error"
      };
    }
  }
  function getDefaultErrorMessage(status) {
    switch (status) {
      case 401:
        return "Unauthorized - please reconnect the extension";
      case 422:
        return "Invalid article content";
      case 429:
        return "Episode limit reached";
      default:
        return `Request failed with status ${status}`;
    }
  }
  async function logExtensionFailure(token, request) {
    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/extension_logs`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(request)
      });
      if (response.ok) {
        const data = await response.json();
        return { success: true, data };
      }
      const errorData = await response.json();
      return {
        success: false,
        status: response.status,
        error: errorData.error || getDefaultErrorMessage(response.status)
      };
    } catch (error) {
      return {
        success: false,
        status: 0,
        error: error instanceof Error ? error.message : "Network error"
      };
    }
  }

  // src/debounce.ts
  var DEBOUNCE_WINDOW_MS = 5e3;
  var lastSuccessfulSend = null;
  function shouldDebounce(url) {
    if (!lastSuccessfulSend) {
      return false;
    }
    const now = Date.now();
    const elapsed = now - lastSuccessfulSend.timestamp;
    if (lastSuccessfulSend.url === url && elapsed < DEBOUNCE_WINDOW_MS) {
      return true;
    }
    return false;
  }
  function recordSuccessfulSend(url) {
    lastSuccessfulSend = {
      url,
      timestamp: Date.now()
    };
  }

  // src/background.ts
  chrome.action.onClicked.addListener(async (tab) => {
    if (!tab.id || !tab.url) {
      console.error("No active tab");
      return;
    }
    if (!tab.url.startsWith("http://") && !tab.url.startsWith("https://")) {
      await setIconState("error");
      return;
    }
    try {
      const connected = await isConnected();
      if (!connected) {
        chrome.tabs.create({ url: "https://www.verynormal.fyi/extension/connect" });
        return;
      }
      if (shouldDebounce(tab.url)) {
        await setIconState("success");
        return;
      }
      await setIconState("loading");
      const response = await chrome.tabs.sendMessage(
        tab.id,
        { type: "EXTRACT_ARTICLE" }
      );
      if (!response) {
        throw new Error("No response from content script");
      }
      if (!response.success) {
        await handleExtractionError(response.error, response.errorType, tab.url);
        return;
      }
      const token = await getToken();
      if (!token) {
        await setIconState("error");
        return;
      }
      const result = await createEpisode(token, {
        title: response.article.title,
        content: response.article.content,
        url: response.article.url,
        author: response.article.author,
        description: response.article.description
      });
      if (result.success) {
        recordSuccessfulSend(tab.url);
        await setIconState("success");
      } else {
        await handleApiError(result.status, result.error, tab.url, token);
      }
    } catch (error) {
      console.error("Error processing article:", error);
      if (error instanceof Error && isNetworkError(error)) {
        await setIconState("offline");
      } else {
        await setIconState("error");
      }
      try {
        const token = await getToken();
        if (token && tab.url) {
          await logExtensionFailure(token, {
            url: tab.url,
            error_type: "EXTENSION_ERROR",
            error_message: error instanceof Error ? error.message : "Unknown error"
          });
        }
      } catch {
      }
    }
  });
  async function handleApiError(status, error, url, token) {
    switch (status) {
      case 401:
        await clearToken();
        await setIconState("error");
        break;
      case 429:
        await setIconState("rate_limited");
        break;
      case 0:
        await setIconState("offline");
        break;
      default:
        await setIconState("error");
        try {
          await logExtensionFailure(token, {
            url,
            error_type: status >= 500 ? "SERVER_ERROR" : "API_ERROR",
            error_message: error
          });
        } catch {
        }
    }
  }
  function isNetworkError(error) {
    const networkErrorMessages = [
      "Failed to fetch",
      "NetworkError",
      "Network request failed",
      "net::ERR_",
      "TypeError: Failed to fetch"
    ];
    return networkErrorMessages.some(
      (msg) => error.message.includes(msg) || error.name.includes(msg)
    );
  }
  async function handleExtractionError(error, errorType, url) {
    await setIconState("error");
    try {
      const token = await getToken();
      if (token) {
        await logExtensionFailure(token, {
          url,
          error_type: errorType,
          error_message: error
        });
      }
    } catch {
    }
  }
  chrome.runtime.onInstalled.addListener(() => {
    console.log("TTS Extension installed");
  });
})();
//# sourceMappingURL=background.js.map
